from setuptools import setup
setup(name="packageboj",
version="0.1",
description="This is code with Reza",
long_description="This is a very very long",
author="Reza",
packages=['packageboj'],
install_requires=[])